/*
 * Dynamics_data.cpp
 *
 * Code generation for model "Dynamics".
 *
 * Model version              : 1.52
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C++ source code generated on : Tue Nov 29 15:05:06 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Dynamics.h"

/* Block parameters (default storage) */
P_Dynamics_T Dynamics::Dynamics_P{
  /* Computed Parameter: Constant2_Value
   * Referenced by: '<Root>/Constant2'
   */
  {
    0.0,                               /* r */
    0.0                                /* v */
  }
};
